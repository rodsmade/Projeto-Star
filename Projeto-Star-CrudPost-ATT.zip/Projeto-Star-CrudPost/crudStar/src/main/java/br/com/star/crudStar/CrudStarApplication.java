package br.com.star.crudStar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudStarApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudStarApplication.class, args);
	}

}
