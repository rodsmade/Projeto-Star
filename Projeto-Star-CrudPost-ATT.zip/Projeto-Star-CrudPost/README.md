# Projeto-Integrador-Generation🌃✨🌌
Projeto final do curso realizado em conjunto com Vittória (@viborotto), Liliane (@LilieMartins), Beatriz (@biasenario) e Gilberto (@GG3T).

# v01 (Rodrigo)
Até agora temos a estrutura principal do BD (usuário, amigos, posts, notificações, etc.)
Falta implementar a parte do Chat no BD.
*'Dump' é como o Workbench chama o script gerado a partir do DER.
